import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import sqlite3, datetime, os, shutil, webbrowser, html, re

BASE = os.path.dirname(os.path.abspath(__file__))
APPDATA = os.path.join(os.environ.get("LOCALAPPDATA", os.path.expanduser("~")), "Saeed Medical Lab")
os.makedirs(APPDATA, exist_ok=True)
DB = os.path.join(APPDATA, "saeed_lab.db")
REPORTS = os.path.join(os.path.expanduser("~"), "Documents", "Saeed Medical Lab Reports")
os.makedirs(REPORTS, exist_ok=True)

def now():
    return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def db():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    return c

def init_db():
    c=db()
    c.executescript("""
    CREATE TABLE IF NOT EXISTS settings(k TEXT PRIMARY KEY,v TEXT);
    CREATE TABLE IF NOT EXISTS users(username TEXT PRIMARY KEY,password TEXT,role TEXT);
    CREATE TABLE IF NOT EXISTS doctors(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT UNIQUE);
    CREATE TABLE IF NOT EXISTS tests(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT UNIQUE);
    CREATE TABLE IF NOT EXISTS params(
      id INTEGER PRIMARY KEY AUTOINCREMENT,test_id INTEGER,name TEXT,unit TEXT,
      low_m REAL,high_m REAL,low_f REAL,high_f REAL,low_o REAL,high_o REAL,
      result_type TEXT DEFAULT 'Numeric',default_value TEXT DEFAULT '',
      ord INTEGER DEFAULT 0);
    CREATE TABLE IF NOT EXISTS visits(
      id INTEGER PRIMARY KEY AUTOINCREMENT,report_no TEXT UNIQUE,patient_name TEXT,
      age_value TEXT,age_unit TEXT,gender TEXT,mobile TEXT,doctor TEXT,
      sample_dt TEXT,report_dt TEXT,remarks TEXT);
    CREATE TABLE IF NOT EXISTS visit_tests(
      id INTEGER PRIMARY KEY AUTOINCREMENT,visit_id INTEGER,test_id INTEGER,result_json TEXT DEFAULT '{}',
      UNIQUE(visit_id,test_id));
    """)
    if not c.execute("SELECT 1 FROM users").fetchone():
        c.execute("INSERT INTO users VALUES('admin','admin','Admin')")
        c.execute("INSERT INTO users VALUES('technician','tech','Lab Technician')")
    if not c.execute("SELECT 1 FROM settings WHERE k='next_no'").fetchone():
        c.execute("INSERT INTO settings VALUES('next_no','1')")
    if not c.execute("SELECT 1 FROM tests").fetchone():
        samples = {
          "CBC":[("Hemoglobin","g/dL",13,17,12,16,12,17),("RBC","10^12/L",4.5,5.9,4.0,5.2,4.0,5.9),
                 ("WBC","10^9/L",4,11,4,11,4,11),("Platelets","10^9/L",150,450,150,450,150,450),
                 ("Neutrophils","%",40,75,40,75,40,75),("Lymphocytes","%",20,45,20,45,20,45)],
          "ALT (SGPT)":[("ALT","U/L",0,41,0,33,0,41)],
          "AST (SGOT)":[("AST","U/L",0,40,0,32,0,40)],
          "Creatinine":[("Creatinine","mg/dL",0.7,1.3,0.6,1.1,0.6,1.3)],
          "Blood Glucose":[("Glucose","mg/dL",70,99,70,99,70,99)],
          "HBsAg":[("HBsAg","",0,0,0,0,0,0)],
          "HCV":[("HCV","",0,0,0,0,0,0)]
        }
        for t, ps in samples.items():
            cur=c.execute("INSERT INTO tests(name) VALUES(?)",(t,))
            tid=cur.lastrowid
            for i,p in enumerate(ps):
                rt="Positive/Negative" if t in ("HBsAg","HCV") else "Numeric"
                dv="Negative" if rt!="Numeric" else ""
                c.execute("""INSERT INTO params(test_id,name,unit,low_m,high_m,low_f,high_f,low_o,high_o,result_type,default_value,ord)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",(tid,*p,rt,dv,i))
    c.commit(); c.close()

def next_report():
    c=db()
    n=int(c.execute("SELECT v FROM settings WHERE k='next_no'").fetchone()[0])
    c.execute("UPDATE settings SET v=? WHERE k='next_no'",(str(n+1),))
    c.commit(); c.close()
    return f"RPT-{n:06d}"

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Saeed Medical Lab — LIS")
        self.geometry("1200x760")
        self.minsize(1000,650)
        self.user=None; self.role=None; self.visit_id=None; self.test_vars={}
        self.login_screen()

    def clear(self):
        for w in self.winfo_children(): w.destroy()

    def login_screen(self):
        self.clear()
        f=ttk.Frame(self,padding=40); f.place(relx=.5,rely=.5,anchor="center")
        ttk.Label(f,text="SAEED MEDICAL LAB",font=("Arial",22,"bold")).grid(row=0,column=0,columnspan=2,pady=20)
        ttk.Label(f,text="Laboratory Information System",font=("Arial",12)).grid(row=1,column=0,columnspan=2,pady=5)
        ttk.Label(f,text="Username").grid(row=2,column=0,sticky="w",pady=8)
        u=ttk.Entry(f,width=30); u.grid(row=2,column=1,pady=8)
        ttk.Label(f,text="Password").grid(row=3,column=0,sticky="w",pady=8)
        p=ttk.Entry(f,width=30,show="*"); p.grid(row=3,column=1,pady=8)
        def go(e=None):
            c=db(); r=c.execute("SELECT * FROM users WHERE username=? AND password=?",(u.get(),p.get())).fetchone(); c.close()
            if not r: messagebox.showerror("Login","Invalid username or password"); return
            self.user=r["username"]; self.role=r["role"]; self.main()
        ttk.Button(f,text="Login",command=go).grid(row=4,column=0,columnspan=2,pady=18)
        ttk.Label(f,text="Default Admin: admin / admin    Technician: technician / tech",foreground="gray").grid(row=5,column=0,columnspan=2)

    def main(self):
        self.clear()
        top=ttk.Frame(self,padding=8); top.pack(fill="x")
        ttk.Label(top,text="Saeed Medical Lab LIS",font=("Arial",18,"bold")).pack(side="left")
        ttk.Label(top,text=f"  {self.user} — {self.role}").pack(side="left",padx=20)
        ttk.Button(top,text="Logout",command=self.login_screen).pack(side="right")
        nb=ttk.Notebook(self); nb.pack(fill="both",expand=True,padx=8,pady=5)
        self.registration_tab(nb)
        self.results_tab(nb)
        self.history_tab(nb)
        if self.role=="Admin":
            self.admin_tab(nb)

    def registration_tab(self,nb):
        fr=ttk.Frame(nb,padding=15); nb.add(fr,text="Patient / Visit")
        form=ttk.LabelFrame(fr,text="Patient Registration",padding=15); form.pack(fill="x")
        self.fields={}
        labels=[("Patient Name","patient_name"),("Age","age_value"),("Mobile","mobile")]
        for i,(lab,key) in enumerate(labels):
            ttk.Label(form,text=lab).grid(row=0,column=i*2,sticky="w",padx=5)
            e=ttk.Entry(form,width=22); e.grid(row=0,column=i*2+1,padx=5); self.fields[key]=e
        ttk.Label(form,text="Age Unit").grid(row=1,column=0,pady=10)
        au=ttk.Combobox(form,values=["Years","Months","Days"],state="readonly",width=18); au.set("Years"); au.grid(row=1,column=1); self.fields["age_unit"]=au
        ttk.Label(form,text="Gender").grid(row=1,column=2)
        ge=ttk.Combobox(form,values=["Male","Female","Other"],state="readonly",width=18); ge.set("Male"); ge.grid(row=1,column=3); self.fields["gender"]=ge
        ttk.Label(form,text="Referring Doctor *").grid(row=1,column=4)
        self.doc=ttk.Combobox(form,width=24); self.doc.grid(row=1,column=5); self.refresh_doctors()
        ttk.Label(form,text="Remarks").grid(row=2,column=0,pady=10)
        self.remarks=ttk.Entry(form,width=70); self.remarks.grid(row=2,column=1,columnspan=5,sticky="w")
        self.no_lbl=ttk.Label(form,text="New report will be assigned automatically",foreground="gray"); self.no_lbl.grid(row=3,column=0,columnspan=3,pady=10,sticky="w")
        ttk.Button(form,text="Create New Visit",command=self.new_visit).grid(row=3,column=5,sticky="e")
        tests=ttk.LabelFrame(fr,text="Select Tests (print checkpoint)",padding=10); tests.pack(fill="both",expand=True,pady=12)
        self.test_vars={}
        c=db()
        rows=c.execute("SELECT * FROM tests ORDER BY name").fetchall(); c.close()
        for i,r in enumerate(rows):
            v=tk.BooleanVar()
            ttk.Checkbutton(tests,text=r["name"],variable=v,command=self.refresh_results).grid(row=i//4,column=i%4,sticky="w",padx=15,pady=7)
            self.test_vars[r["id"]]=v
        ttk.Button(fr,text="Open Selected Tests / Enter Results",command=self.refresh_results).pack(anchor="e")

    def new_visit(self):
        if not self.fields["patient_name"].get().strip() or not self.doc.get().strip():
            messagebox.showwarning("Required","Patient Name اور Referring Doctor ضروری ہیں."); return
        rn=next_report()
        c=db()
        cur=c.execute("""INSERT INTO visits(report_no,patient_name,age_value,age_unit,gender,mobile,doctor,sample_dt,remarks)
        VALUES(?,?,?,?,?,?,?,?,?)""",(rn,self.fields["patient_name"].get().strip(),self.fields["age_value"].get().strip() or "--",
        self.fields["age_unit"].get(),self.fields["gender"].get(),self.fields["mobile"].get().strip() or "--",
        self.doc.get().strip(),now(),self.remarks.get().strip()))
        self.visit_id=cur.lastrowid; c.commit(); c.close()
        self.no_lbl.config(text=f"Report No: {rn}",foreground="green")
        messagebox.showinfo("Created",f"Visit created.\nReport No: {rn}")

    def refresh_doctors(self):
        c=db(); vals=[r["name"] for r in c.execute("SELECT name FROM doctors ORDER BY name")]; c.close()
        self.doc["values"]=vals

    def refresh_results(self):
        if not self.visit_id:
            messagebox.showwarning("Visit","پہلے New Visit بنائیں۔"); return
        self.build_result_area()

    def results_tab(self,nb):
        fr=ttk.Frame(nb,padding=10); nb.add(fr,text="Results")
        self.res_container=fr
        ttk.Label(fr,text="Selected Tests — enter results below",font=("Arial",14,"bold")).pack(anchor="w")
        self.build_result_area()

    def build_result_area(self):
        if not hasattr(self,"res_container"): return
        for w in self.res_container.winfo_children():
            if w.winfo_name()!="!label": w.destroy()
        canvas=tk.Canvas(self.res_container); sb=ttk.Scrollbar(self.res_container,orient="vertical",command=canvas.yview)
        inner=ttk.Frame(canvas); inner.bind("<Configure>",lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0,0),window=inner,anchor="nw"); canvas.configure(yscrollcommand=sb.set)
        canvas.pack(side="left",fill="both",expand=True); sb.pack(side="right",fill="y")
        self.result_entries={}
        c=db()
        selected=[tid for tid,v in self.test_vars.items() if v.get()]
        for tid in selected:
            tr=c.execute("SELECT * FROM tests WHERE id=?",(tid,)).fetchone()
            lf=ttk.LabelFrame(inner,text=tr["name"],padding=8); lf.pack(fill="x",pady=7)
            ttk.Label(lf,text="Parameter",width=28).grid(row=0,column=0)
            ttk.Label(lf,text="Result",width=18).grid(row=0,column=1)
            ttk.Label(lf,text="Unit",width=14).grid(row=0,column=2)
            ttk.Label(lf,text="Reference Range",width=24).grid(row=0,column=3)
            ttk.Label(lf,text="Flag",width=10).grid(row=0,column=4)
            old={}
            if self.visit_id:
                vr=c.execute("SELECT result_json FROM visit_tests WHERE visit_id=? AND test_id=?",(self.visit_id,tid)).fetchone()
                if vr:
                    try: old=json.loads(vr["result_json"])
                    except: pass
            ps=c.execute("SELECT * FROM params WHERE test_id=? ORDER BY ord,id",(tid,)).fetchall()
            for i,p in enumerate(ps,1):
                ttk.Label(lf,text=p["name"]).grid(row=i,column=0,sticky="w",padx=5,pady=4)
                ent=ttk.Entry(lf,width=18); ent.grid(row=i,column=1,padx=5)
                val=old.get(str(p["id"]),p["default_value"] or "")
                ent.insert(0,val)
                ttk.Label(lf,text=p["unit"] or "--").grid(row=i,column=2)
                ref=self.ref_for(p)
                ttk.Label(lf,text=ref).grid(row=i,column=3)
                flag=ttk.Label(lf,text=""); flag.grid(row=i,column=4)
                def make_update(e=ent,f=flag,pp=p):
                    self.flag_result(e,f,pp)
                ent.bind("<KeyRelease>",make_update); make_update()
                self.result_entries[p["id"]]=(ent,p,flag,tid)
        b=ttk.Frame(inner,padding=10); b.pack(fill="x")
        ttk.Button(b,text="Save Results",command=self.save_results).pack(side="left",padx=5)
        ttk.Button(b,text="Print Selected Tests",command=self.print_report).pack(side="left",padx=5)

    def ref_for(self,p):
        g=self.current_gender()
        if p["result_type"]!="Numeric": return "--"
        lo,hi=(p["low_m"],p["high_m"]) if g=="Male" else ((p["low_f"],p["high_f"]) if g=="Female" else (p["low_o"],p["high_o"]))
        if lo is None or hi is None or (lo==0 and hi==0): return "--"
        return f"{lo:g} - {hi:g}"

    def current_gender(self):
        try: return self.fields["gender"].get()
        except: return "Male"

    def flag_result(self,e,f,p):
        if p["result_type"]!="Numeric": f.config(text=""); return
        try: x=float(e.get()); 
        except: f.config(text=""); return
        g=self.current_gender()
        lo,hi=(p["low_m"],p["high_m"]) if g=="Male" else ((p["low_f"],p["high_f"]) if g=="Female" else (p["low_o"],p["high_o"]))
        if lo is None or hi is None or (lo==0 and hi==0): f.config(text=""); return
        f.config(text="LOW" if x<lo else ("HIGH" if x>hi else "NORMAL"))

    def save_results(self):
        if not self.visit_id: return
        c=db()
        by={}
        for pid,(e,p,flag,tid) in self.result_entries.items():
            by.setdefault(tid,{})[str(pid)]=e.get().strip()
        for tid,d in by.items():
            c.execute("""INSERT INTO visit_tests(visit_id,test_id,result_json) VALUES(?,?,?)
            ON CONFLICT(visit_id,test_id) DO UPDATE SET result_json=excluded.result_json""",(self.visit_id,tid,json.dumps(d)))
        c.commit(); c.close()
        messagebox.showinfo("Saved","Results saved successfully.")

    def print_report(self):
        if not self.visit_id: return
        self.save_results()
        c=db(); v=c.execute("SELECT * FROM visits WHERE id=?",(self.visit_id,)).fetchone()
        selected=[tid for tid,x in self.test_vars.items() if x.get()]
        if not selected:
            messagebox.showwarning("Print","کم از کم ایک test select کریں۔"); c.close(); return
        report_dt=v["report_dt"] or now()
        if not v["report_dt"]:
            c.execute("UPDATE visits SET report_dt=? WHERE id=?",(report_dt,self.visit_id)); c.commit()
            v=c.execute("SELECT * FROM visits WHERE id=?",(self.visit_id,)).fetchone()
        blocks=[]
        for tid in selected:
            t=c.execute("SELECT * FROM tests WHERE id=?",(tid,)).fetchone()
            vt=c.execute("SELECT result_json FROM visit_tests WHERE visit_id=? AND test_id=?",(self.visit_id,tid)).fetchone()
            data=json.loads(vt["result_json"]) if vt else {}
            rows=[]
            for p in c.execute("SELECT * FROM params WHERE test_id=? ORDER BY ord,id",(tid,)).fetchall():
                val=data.get(str(p["id"]),"")
                flag=""
                if p["result_type"]=="Numeric":
                    try:
                        x=float(val); g=v["gender"]
                        lo,hi=(p["low_m"],p["high_m"]) if g=="Male" else ((p["low_f"],p["high_f"]) if g=="Female" else (p["low_o"],p["high_o"]))
                        if lo is not None and hi is not None and not(lo==0 and hi==0): flag="LOW" if x<lo else ("HIGH" if x>hi else "")
                    except: pass
                rows.append(f"<tr><td>{html.escape(p['name'])}</td><td><b>{html.escape(val)}</b></td><td>{html.escape(p['unit'] or '--')}</td><td>{html.escape(self.ref_for_row(p,v['gender']))}</td><td>{flag}</td></tr>")
            blocks.append(f"<h3>{html.escape(t['name'])}</h3><table><tr><th>Parameter</th><th>Result</th><th>Unit</th><th>Reference Range</th><th></th></tr>{''.join(rows)}</table>")
        remarks=f"<p><b>Remarks:</b> {html.escape(v['remarks'])}</p>" if v["remarks"] else ""
        page=f"""<!doctype html><html><head><meta charset='utf-8'><title>{v['report_no']}</title>
        <style>@page{{size:F4;margin:2.5in .5in .5in .5in}}body{{font-family:Arial;font-size:11pt}}table{{width:100%;border-collapse:collapse}}th,td{{border:1px solid #444;padding:6px}}th{{background:#eee}}h3{{margin-top:14px}}</style></head><body>
        <div><b>Report No:</b> {v['report_no']} &nbsp; <b>Patient:</b> {html.escape(v['patient_name'])}<br>
        <b>Age:</b> {html.escape(v['age_value'])} {html.escape(v['age_unit'])} &nbsp; <b>Gender:</b> {html.escape(v['gender'])} &nbsp; <b>Mobile:</b> {html.escape(v['mobile'])}<br>
        <b>Referring Doctor:</b> {html.escape(v['doctor'])}<br>
        <b>Sample Collection:</b> {v['sample_dt']} &nbsp; <b>Report Date:</b> {report_dt}</div>{''.join(blocks)}{remarks}
        </body></html>"""
        path=os.path.join(REPORTS,f"{v['report_no']}.html")
        open(path,"w",encoding="utf-8").write(page); c.close()
        webbrowser.open("file://"+os.path.abspath(path))

    def ref_for_row(self,p,g):
        if p["result_type"]!="Numeric": return "--"
        lo,hi=(p["low_m"],p["high_m"]) if g=="Male" else ((p["low_f"],p["high_f"]) if g=="Female" else (p["low_o"],p["high_o"]))
        return "--" if lo is None or hi is None or (lo==0 and hi==0) else f"{lo:g} - {hi:g}"

    def history_tab(self,nb):
        fr=ttk.Frame(nb,padding=10); nb.add(fr,text="Search / History")
        q=tk.StringVar(); ttk.Entry(fr,textvariable=q,width=35).pack(side="left")
        tree=ttk.Treeview(fr,columns=("no","name","date"),show="headings")
        for col,h in [("no","Report No"),("name","Patient"),("date","Sample Date")]: tree.heading(col,text=h)
        tree.pack(fill="both",expand=True,pady=10)
        def search():
            tree.delete(*tree.get_children()); c=db()
            rows=c.execute("SELECT * FROM visits WHERE report_no LIKE ? OR patient_name LIKE ? ORDER BY id DESC",(f"%{q.get()}%",f"%{q.get()}%")).fetchall(); c.close()
            for r in rows: tree.insert("", "end",values=(r["report_no"],r["patient_name"],r["sample_dt"]),iid=str(r["id"]))
        ttk.Button(fr,text="Search",command=search).pack(side="left",padx=5)
        def load():
            sel=tree.selection()
            if not sel: return
            self.load_visit(int(sel[0]))
        ttk.Button(fr,text="Open Visit",command=load).pack(side="left")
        search()

    def load_visit(self,vid):
        c=db(); v=c.execute("SELECT * FROM visits WHERE id=?",(vid,)).fetchone()
        self.visit_id=vid
        for k in ("patient_name","age_value","mobile"):
            self.fields[k].delete(0,"end"); self.fields[k].insert(0,v[k] or "")
        self.fields["age_unit"].set(v["age_unit"] or "Years"); self.fields["gender"].set(v["gender"] or "Male"); self.doc.set(v["doctor"] or "")
        self.remarks.delete(0,"end"); self.remarks.insert(0,v["remarks"] or "")
        for tid,var in self.test_vars.items(): var.set(bool(c.execute("SELECT 1 FROM visit_tests WHERE visit_id=? AND test_id=?",(vid,tid)).fetchone()))
        c.close(); self.build_result_area()

    def admin_tab(self,nb):
        fr=ttk.Frame(nb,padding=10); nb.add(fr,text="Admin / Test Master")
        left=ttk.LabelFrame(fr,text="Tests"); left.pack(side="left",fill="y",padx=5)
        lb=tk.Listbox(left,width=28); lb.pack(fill="y",expand=True)
        right=ttk.Frame(fr,padding=10); right.pack(side="left",fill="both",expand=True)
        def refresh():
            lb.delete(0,"end"); c=db()
            for r in c.execute("SELECT * FROM tests ORDER BY name"): lb.insert("end",f"{r['id']} | {r['name']}")
            c.close()
        ttk.Label(right,text="Test Name").pack(anchor="w"); tn=ttk.Entry(right,width=40); tn.pack(anchor="w")
        ttk.Button(right,text="Add Test",command=lambda:add()).pack(anchor="w",pady=5)
        pframe=ttk.LabelFrame(right,text="Parameters (select a test)"); pframe.pack(fill="both",expand=True,pady=8)
        def add():
            if not tn.get().strip(): return
            c=db()
            try: c.execute("INSERT INTO tests(name) VALUES(?)",(tn.get().strip(),)); c.commit()
            except sqlite3.IntegrityError: messagebox.showwarning("Test","Test already exists.")
            c.close(); tn.delete(0,"end"); refresh()
        def selected_test():
            s=lb.curselection()
            return int(lb.get(s[0]).split("|")[0]) if s else None
        def show_params(e=None):
            for w in pframe.winfo_children(): w.destroy()
            tid=selected_test()
            if not tid:return
            c=db(); ps=c.execute("SELECT * FROM params WHERE test_id=? ORDER BY ord,id",(tid,)).fetchall(); c.close()
            cols=["Name","Unit","Low M","High M","Low F","High F","Type","Default"]
            for j,h in enumerate(cols): ttk.Label(pframe,text=h).grid(row=0,column=j,padx=3,pady=3)
            entries=[]
            for i,p in enumerate(ps,1):
                vals=[p["name"],p["unit"],p["low_m"],p["high_m"],p["low_f"],p["high_f"],p["result_type"],p["default_value"]]
                row=[]
                for j,val in enumerate(vals):
                    e=ttk.Entry(pframe,width=14); e.insert(0,str(val)); e.grid(row=i,column=j,padx=2,pady=2); row.append(e)
                entries.append((p["id"],row))
            def savep():
                c=db()
                for pid,row in entries:
                    try:
                        c.execute("""UPDATE params SET name=?,unit=?,low_m=?,high_m=?,low_f=?,high_f=?,result_type=?,default_value=? WHERE id=?""",
                        (row[0].get(),row[1].get(),float(row[2].get() or 0),float(row[3].get() or 0),float(row[4].get() or 0),float(row[5].get() or 0),row[6].get(),row[7].get(),pid))
                    except ValueError: pass
                c.commit(); c.close(); messagebox.showinfo("Saved","Parameters updated.")
            ttk.Button(pframe,text="Save Parameter Changes",command=savep).grid(row=len(ps)+1,column=0,columnspan=3,pady=8)
        lb.bind("<<ListboxSelect>>",show_params)
        refresh()
        tools=ttk.Frame(fr); tools.pack(side="bottom",fill="x",pady=5)
        def backup():
            path=filedialog.asksaveasfilename(defaultextension=".db",filetypes=[("Database","*.db")])
            if path: shutil.copy2(DB,path)
        ttk.Button(tools,text="Backup Database",command=backup).pack(side="left",padx=5)
        def doctor():
            n=tk.simpledialog.askstring("Doctor","Doctor name:")
            if n:
                c=db(); c.execute("INSERT OR IGNORE INTO doctors(name) VALUES(?)",(n,)); c.commit(); c.close(); self.refresh_doctors()
        import tkinter.simpledialog
        ttk.Button(tools,text="Add Doctor",command=doctor).pack(side="left",padx=5)

if __name__=="__main__":
    init_db()
    App().mainloop()
