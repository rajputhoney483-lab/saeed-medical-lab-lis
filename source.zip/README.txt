SAEED MEDICAL LAB — FUNCTIONAL WORKING BUILD

Run:
1. Install Python 3.11+ on Windows.
2. Double-click run.bat OR run: python saeed_lab_lis.py

Default logins:
Admin: admin / admin
Lab Technician: technician / tech

This is an offline functional desktop prototype/source build. It is NOT a compiled Setup.exe installer.
Reports open as HTML for printing; F4 page size and 2.5-inch top margin are configured in the print CSS.
