@echo off
python saeed_lab_lis.py
pause
